$(document).ready(function() {
    //$(".numeric-bullet-style").html("1");
    //console.log(ary);
});